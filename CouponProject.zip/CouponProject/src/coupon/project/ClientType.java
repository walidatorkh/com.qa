package coupon.project;

public enum ClientType {

	COMPANY,
	CUSTOMER,
	ADMIN;
	
}
