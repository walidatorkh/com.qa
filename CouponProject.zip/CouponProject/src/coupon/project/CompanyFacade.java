package coupon.project;

public class CompanyFacade implements CouponClientFacade {

	public static CouponClientFacade login(String name, String password) {
		
		/*
		 * Connect to the DAO and check if such user and password exist.
		 * If exist - return a company facade object, else - return null or throw exception.
		 */
		
		// If success
		return new CompanyFacade();
	}
	
	public  void createCoupon( /* parameters */ ) {
		
	}

}
