package coupon.project;

public class CouponSystem {

	public CouponClientFacade login ( String name, String password, ClientType clientType) {
		
		switch ( clientType ) {
			case COMPANY:
				return CompanyFacade.login(name, password);
			case CUSTOMER:
				return CustomerFacade.login(name, password);
			case ADMIN:
				return AdminFacade.login(name, password);
		}
		
	}
	
}
