package coupon.project.test;

import coupon.project.ClientType;
import coupon.project.CompanyFacade;
import coupon.project.CouponSystem;

public class Main {

	public static void main(String[] args) {

		CouponSystem couponSystem = new CouponSystem(); /* You will do it as a singelton */
		
		CompanyFacade currentFacade = (CompanyFacade) couponSystem.login("myCompany", "secret123", ClientType.COMPANY);
		currentFacade.createCoupon();
	}

}
