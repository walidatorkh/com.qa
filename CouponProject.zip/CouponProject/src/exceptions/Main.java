package exceptions;

import coupon.project.CouponSystemException;

public class Main {

	public static void main(String[] args) throws Exception {
		divideByZero6();
	}

	private static void divideByZero1() {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			/* Do nothing */
		}
	}
	
	private static void divideByZero2() {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			System.out.println( e.getMessage() );
		}
	}
	
	private static void divideByZero3() throws Exception {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			throw new Exception();
		}
	}
	
	private static void divideByZero4() throws Exception {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			throw new Exception("You tried to divide by zero!");
		}
	}
	
	private static void divideByZero5() throws Exception {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			throw new Exception("You tried to divide by zero!",e);
		}
	}
	
	private static void divideByZero6() throws Exception {
		int x = 0;
		try {
			double result =  10 / x;
		} catch ( ArithmeticException e ) {
			throw new 
("You tried to divide by zero!",e);
		}
	}

}
