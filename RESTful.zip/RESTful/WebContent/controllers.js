

angular.module('myApp', []);

angular.module('myApp').controller('toDoController', function($scope, $http) {
	
	$scope.showDiv=false;

	$http.get("rest/jaxb/todo/json").success(function(response2) { $scope.task = response2;});
	
	$scope.showToDoDiv=function(){	
		if($scope.showDiv==false){
			$http.get("rest/jaxb/todo/all").success(function(response) { $scope.todo = response.todo;});
			$scope.showDiv=true;
		}else{
			$scope.showDiv=false;
		}
	};
});