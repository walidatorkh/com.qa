package simple.example;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/calc")
public class Calculator {
	
	@GET
	@Path("/add/{firstArgument}/{secondArgument}")
	@Produces(MediaType.TEXT_PLAIN)
	public String add( @PathParam("firstArgument") int a, @PathParam("secondArgument")int b) {
		return a + b + "";
	}

	@GET
	@Path("/sub")
	@Produces(MediaType.TEXT_PLAIN)
	public String sub( @QueryParam("a") @DefaultValue("15") int a, @QueryParam("b") @DefaultValue("5") int b) {
		return a - b + "";
	}
	
}
