

	package client;

	import java.net.URI;

import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

	import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.RequestBuilder;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

	public class RESTfulSessionClient {
	  public static void main(String[] args) {
	    ClientConfig config = new DefaultClientConfig();
	    Client client = Client.create(config);
	    WebResource service = client.resource(getBaseURI());

	    ClientResponse resp = service.path("rest").path("sessions").accept(MediaType.TEXT_PLAIN).get(ClientResponse.class);
	   
	    //fetch session cookie
	    //in order to be more portable - simply load ALL cookies instead of searching for a specific one..
	    Cookie sid=null;
	    for(Cookie c:resp.getCookies()){
	    	if(c.getName().equals("JSESSIONID")){
	    		sid=c;
	    		break;
	    	}
	    }
	    System.out.println(resp.getEntity(String.class));
	    sendRequest(service, sid, 10);
	    sendRequest(service, sid, 5);
	    sendRequest(service, sid, 3);

	  }

	  private static URI getBaseURI() {
	    return UriBuilder.fromUri("http://localhost:8080/RESTful").build();
	  }
	  
	  private static void sendRequest(WebResource service, Cookie sid, int value){
		    WebResource wr=service.path("rest").path("sessions").path("add").queryParam("num", value+"");
		    //get builder to mount session cookie (since WebResource is immutable - we must work with Builders)
		    WebResource.Builder builder=wr.getRequestBuilder();
		    builder.cookie(sid);
		    builder.accept(MediaType.TEXT_PLAIN);
		    System.out.println(builder.get(String.class));
	  }

	} 
