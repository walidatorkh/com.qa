

	package client;

	import java.net.URI;

	import javax.ws.rs.core.MediaType;
	import javax.ws.rs.core.UriBuilder;

	import com.sun.jersey.api.client.Client;
	import com.sun.jersey.api.client.ClientResponse;
	import com.sun.jersey.api.client.WebResource;
	import com.sun.jersey.api.client.config.ClientConfig;
	import com.sun.jersey.api.client.config.DefaultClientConfig;

	public class RESTfulItemClient {
	  public static void main(String[] args) {
	    ClientConfig config = new DefaultClientConfig();
	    Client client = Client.create(config);
	    WebResource service = client.resource(getBaseURI());
	    // get token
	    System.out.print("Getting token...");
	    String token = service.path("rest").path("items").path("createCart").accept(MediaType.TEXT_PLAIN).get(String.class);
	    System.out.println("got: "+token);
	    // add items
	    System.out.println("Adding items");
	    System.out.println(service.path("rest").path("items").path(token).queryParam("name", "Item 1").queryParam("price", "100.55").accept(MediaType.TEXT_PLAIN).post(String.class));
	    System.out.println(service.path("rest").path("items").path(token).queryParam("name", "Item 2").queryParam("price", "16.78").accept(MediaType.TEXT_PLAIN).post(String.class));
	    // get items in JSON format
	    System.out.println("Fetching items");
	    System.out.println(service.path("rest").path("items").path(token).accept(MediaType.APPLICATION_JSON).get(String.class));
	    // remove one item and print all again...
	    System.out.println("Removing one item");
	    System.out.println(service.path("rest").path("items").path(token).queryParam("name", "Item 1").accept(MediaType.TEXT_PLAIN).delete(String.class));
	    System.out.println("Fetching items again...");
	    System.out.println(service.path("rest").path("items").path(token).accept(MediaType.APPLICATION_JSON).get(String.class));
	  }

	  private static URI getBaseURI() {
	    return UriBuilder.fromUri("http://localhost:8080/RESTful").build();
	  }

	} 
